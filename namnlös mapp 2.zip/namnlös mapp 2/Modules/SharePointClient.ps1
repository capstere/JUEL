﻿# ── Tillstånd ──────────────────────────────────────────────────────────────
$script:SpRunspace   = $null   # [System.Management.Automation.Runspaces.Runspace]
$script:SpPowerShell = $null   # [System.Management.Automation.PowerShell]  (återanvänds)
$script:SpAsyncHandle = $null  # IAsyncResult från BeginInvoke
$script:SpAsyncPS     = $null  # PowerShell-objekt för pågående async

$global:SpConnected  = $false
$global:SpError      = $null
$global:SpConnecting = $false

# ── Start-SPClient ─────────────────────────────────────────────────────────
function Start-SPClient {

    param(
        [scriptblock]$ProgressCallback = $null
    )

    if ($script:SpRunspace -and $script:SpRunspace.RunspaceStateInfo.State -eq 'Opened') {
        return $true
    }

    try {
        # Skapa runspace med STA apartment (krävs av PnP i vissa scenarier)
        $script:SpRunspace = [System.Management.Automation.Runspaces.RunspaceFactory]::CreateRunspace()
        $script:SpRunspace.ApartmentState = [System.Threading.ApartmentState]::STA
        $script:SpRunspace.ThreadOptions  = [System.Management.Automation.Runspaces.PSThreadOptions]::ReuseThread
        $script:SpRunspace.Open()

        # Stäng av update-check inuti runspace
        $null = _Invoke-InRunspace -Script {
            $env:PNPPOWERSHELL_UPDATECHECK = 'Off'
            $ProgressPreference = 'SilentlyContinue'
        }

        # NuGet bootstrap
        if ($ProgressCallback) { & $ProgressCallback 'Förbereder appen…' }
        $null = _Invoke-InRunspace -Script {
            try { $null = Get-PackageProvider -Name 'NuGet' -ForceBootstrap -ErrorAction SilentlyContinue } catch {}
        }

        # Import PnP.PowerShell (eller installera först)
        if ($ProgressCallback) { & $ProgressCallback 'Förbereder SharePoint-kopplingen…' }
        $importResult = _Invoke-InRunspace -Script {
            try {
                Import-Module PnP.PowerShell -ErrorAction Stop
                return @{ Ok = $true }
            } catch {
                try {
                    Install-Module PnP.PowerShell -MaximumVersion 1.12.0 -Scope CurrentUser -Force -AllowClobber -ErrorAction Stop
                    Import-Module PnP.PowerShell -ErrorAction Stop
                    return @{ Ok = $true }
                } catch {
                    return @{ Ok = $false; Err = $_.Exception.ToString() }
                }
            }
        }

        if (-not $importResult -or -not $importResult.Ok) {
            $global:SpError = if ($importResult -and $importResult.Err) { $importResult.Err } else { 'SharePoint-kopplingen misslyckades (okänt)' }
            return $false
        }

        return $true

    } catch {
        try { Stop-SPClient } catch {}
        $global:SpError = "Start-SPClient: $($_.Exception.ToString())"
        return $false
    }
}

# ── Connect-SPClient (synkron) ─────────────────────────────────────────────
function Connect-SPClient {
    param(
        [scriptblock]$ProgressCallback = $null
    )

    if (-not $script:SpRunspace -or $script:SpRunspace.RunspaceStateInfo.State -ne 'Opened') {
        $global:SpError = 'SharePoint-kopplingen ej startad.'
        return $false
    }

    if ($ProgressCallback) { & $ProgressCallback 'Ansluter…' }

    $url    = $global:SP_SiteUrl
    $tenant = $global:SP_Tenant
    $cid    = $global:SP_ClientId
    $cert   = $global:SP_CertBase64

    $result = _Invoke-InRunspace -Script {
        param($u,$t,$c,$b)
        try {
            Connect-PnPOnline -Url $u -Tenant $t -ClientId $c -CertificateBase64Encoded $b -ErrorAction Stop
            return @{ Ok = $true }
        } catch {
            return @{ Ok = $false; Err = $_.Exception.ToString() }
        }
    } -Arguments @($url, $tenant, $cid, $cert)

    if ($result -and $result.Ok) {
        $global:SpConnected = $true
        $global:SpError     = $null
        return $true
    } else {
        $global:SpConnected = $false
        $global:SpError     = if ($result -and $result.Err) { $result.Err } else { 'SharePoint-kopplingen misslyckades (okänt)' }
        return $false
    }
}

# ── Connect-SPClientAsync ──────────────────────────────────────────────────
function Connect-SPClientAsync {

    if ($global:SpConnecting) { return $false }
    if (-not $script:SpRunspace -or $script:SpRunspace.RunspaceStateInfo.State -ne 'Opened') {
        $global:SpError = 'SharePoint-kopplingen offline.'
        return $false
    }

    $global:SpConnecting = $true

    $url    = $global:SP_SiteUrl
    $tenant = $global:SP_Tenant
    $cid    = $global:SP_ClientId
    $cert   = $global:SP_CertBase64

    $ps = $null
    try {
        $ps = [System.Management.Automation.PowerShell]::Create()
        $ps.Runspace = $script:SpRunspace

        $null = $ps.AddScript({
            param($u,$t,$c,$b)
            try {
                Connect-PnPOnline -Url $u -Tenant $t -ClientId $c -CertificateBase64Encoded $b -ErrorAction Stop
                return @{ Ok = $true }
            } catch {
                return @{ Ok = $false; Err = $_.Exception.ToString() }
            }
        }).AddArgument($url).AddArgument($tenant).AddArgument($cid).AddArgument($cert)

        $script:SpAsyncPS     = $ps
        $script:SpAsyncHandle = $ps.BeginInvoke()
        return $true
    } catch {
        try { if ($ps) { $ps.Dispose() } } catch {}
        $script:SpAsyncPS     = $null
        $script:SpAsyncHandle = $null
        $global:SpConnected   = $false
        $global:SpConnecting  = $false
        $global:SpError       = "Connect-SPClientAsync: $($_.Exception.ToString())"
        return $false
    }
}

# ── Poll-SPClientAsync ─────────────────────────────────────────────────────
function Poll-SPClientAsync {

    if (-not $script:SpAsyncHandle -or -not $script:SpAsyncPS) {
        return $null
    }

    if (-not $script:SpAsyncHandle.IsCompleted) {
        return $null
    }

    # Hämta resultat
    $result = $null
    try {
        $output = $script:SpAsyncPS.EndInvoke($script:SpAsyncHandle)
        if ($output -and $output.Count -gt 0) {
            $result = $output[$output.Count - 1]
        }
    } catch {
        $result = @{ Ok = $false; Err = $_.Exception.ToString() }
    }

    # Städa
    try { $script:SpAsyncPS.Dispose() } catch {}
    $script:SpAsyncPS     = $null
    $script:SpAsyncHandle = $null

    # Uppdatera global state
    if ($result -and $result.Ok) {
        $global:SpConnected  = $true
        $global:SpError      = $null
    } else {
        $global:SpConnected  = $false
        $global:SpError      = if ($result -and $result.Err) { $result.Err } else { 'Okänt fel' }
    }
    $global:SpConnecting = $false

    return $result
}

# ── Invoke-SPClient ────────────────────────────────────────────────────────
function Invoke-SPClient {
    param(
        [Parameter(Mandatory=$true)]
        [scriptblock]$Script,
        [object[]]$Arguments
    )

    if (-not $script:SpRunspace -or $script:SpRunspace.RunspaceStateInfo.State -ne 'Opened') {
        throw 'SPClient-runspace ej startad.'
    }

    return (_Invoke-InRunspace -Script $Script -Arguments $Arguments)
}

# ── Get-SPClientStatus ─────────────────────────────────────────────────────
function Get-SPClientStatus {
    return [pscustomobject]@{
        Connected  = [bool]$global:SpConnected
        Connecting = [bool]$global:SpConnecting
        Error      = $global:SpError
        RunspaceOk = ($null -ne $script:SpRunspace -and $script:SpRunspace.RunspaceStateInfo.State -eq 'Opened')
    }
}

# ── Stop-SPClient ──────────────────────────────────────────────────────────
function Stop-SPClient {
    try {
        if ($script:SpAsyncPS) {
            try { $script:SpAsyncPS.Stop() } catch {}
            try { $script:SpAsyncPS.Dispose() } catch {}
            $script:SpAsyncPS     = $null
            $script:SpAsyncHandle = $null
        }
        if ($script:SpRunspace) {
            try { $script:SpRunspace.Close() } catch {}
            try { $script:SpRunspace.Dispose() } catch {}
            $script:SpRunspace = $null
        }
    } catch {}
    $global:SpConnected  = $false
    $global:SpConnecting = $false
}

# ── Intern hjälpfunktion ───────────────────────────────────────────────────
function _Invoke-InRunspace {
    param(
        [Parameter(Mandatory=$true)]
        [scriptblock]$Script,
        [object[]]$Arguments
    )

    $ps = [System.Management.Automation.PowerShell]::Create()
    $ps.Runspace = $script:SpRunspace

    $null = $ps.AddScript($Script)
    if ($null -ne $Arguments) {
        foreach ($a in $Arguments) {
            $null = $ps.AddArgument($a)
        }
    }

    try {
        $output = $ps.Invoke()
        if ($ps.Streams.Error.Count -gt 0) {
            $errText = ($ps.Streams.Error | ForEach-Object { $_.ToString() }) -join '; '

            try { Write-Host "[SPClient WARN] Non-terminating error: $errText" } catch {}
        }
        if ($output -and $output.Count -gt 0) {
            return $output[$output.Count - 1]
        }
        return $null
    } finally {
        $ps.Dispose()
    }
}