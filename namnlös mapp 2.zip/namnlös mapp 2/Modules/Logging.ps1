﻿try { Add-Type -AssemblyName System.Windows.Forms -ErrorAction Stop } catch { }

function Test-HasGetConfigValue {
    try {
        if ($script:__HasGetConfigValue) { return $true }
    } catch {}

    try {
        $cmd = Get-Command Get-ConfigValue -ErrorAction SilentlyContinue
        if ($cmd) {
            $script:__HasGetConfigValue = $true
            return $true
        }
    } catch {}

    return $false
}

function Get-GuiAppendAction {
    try {
        if ($script:__GuiAppendAction) { return $script:__GuiAppendAction }
    } catch {}

    $script:__GuiAppendAction = [System.Action[System.Windows.Forms.TextBox,string]]{
        param($tbox, $text)
        $tbox.AppendText("$text`r`n")
        $tbox.SelectionStart = $tbox.TextLength
        $tbox.ScrollToCaret()
        $tbox.Refresh()
    }
    return $script:__GuiAppendAction
}

function Get-SafeFileNameComponent {
    param(
        [string]$Value,
        [string]$Default = 'NA'
    )

    $s = ($Value + '').Trim()
    if (-not $s) { return $Default }

    foreach ($ch in [System.IO.Path]::GetInvalidFileNameChars()) {
        $s = $s.Replace([string]$ch, '_')
    }

    $s = [regex]::Replace($s, '\s+', ' ').Trim()
    if (-not $s) { return $Default }
    return $s
}

function Get-OutputBox {
    try { return $script:outputBox } catch { return $null }
}

function Set-LogOutputControl {
    param([System.Windows.Forms.TextBox]$Control)
    $script:outputBox = $Control
}

function Get-GuiLogVerbosity {
    # Läser Config.GuiLogVerbosity (DEV/NORMAL/QUIET). Standard är DEV för bakåtkompatibilitet.
    try {
        $v = $null
        if (Test-HasGetConfigValue) {
            $v = Get-ConfigValue -Name 'GuiLogVerbosity' -Default $null
        } elseif ($global:Config) {
            $v = $global:Config['GuiLogVerbosity']
        }
        $v = ($v + '').Trim().ToUpperInvariant()
        if ($v) { return $v }
    } catch { }
    return 'DEV'
}

function Get-GuiLogList {
    param(
        [Parameter(Mandatory=$true)][string]$Name,
        [string[]]$Default
    )
    $v = $null
    try {
        if (Test-HasGetConfigValue) {
            $v = Get-ConfigValue -Name $Name -Default $Default
        } elseif ($global:Config) {
            $v = $global:Config[$Name]
        }
    } catch { $v = $null }

    if ($null -eq $v) { return @($Default) }
    if ($v -is [string]) { return @($v) }
    return @($v)
}

function Should-LogToGui {
    param(
        [ValidateSet('Info','Warn','Error')][string]$Severity,
        [string]$Category = 'UI'
    )
    $v = Get-GuiLogVerbosity
    $cat = ($Category + '').Trim().ToUpperInvariant()

    if ($v -eq 'DEV') { return $true }

    # QUIET: visa bara det slutanvändaren behöver
    if ($v -eq 'QUIET') {
        if ($Severity -eq 'Error') { return $true }
        if ($Severity -eq 'Warn') { return $true }
        # Info-nivå
        $allow = Get-GuiLogList -Name 'GuiLogInfoCategoriesQuiet' -Default @('SUMMARY','RESULT','USER') |
            ForEach-Object { (($_ + '').Trim()).ToUpperInvariant() }
        return ($allow -contains $cat)
    }

    # NORMAL: dölj bara den mest brusiga diagnostiken
    if ($Severity -eq 'Error') { return $true }
    if ($Severity -eq 'Warn')  { return $true }
    $hide = Get-GuiLogList -Name 'GuiLogInfoHiddenCategoriesNormal' -Default @('DEBUG','SANITY','PROGRESS','RuleEngineStats','RuleEngineDev') |
        ForEach-Object { (($_ + '').Trim()).ToUpperInvariant() }
    return ($hide -notcontains $cat)
}

function Gui-Log {
    param(
        [string]$Text,
        [ValidateSet('Info', 'Warn', 'Error')]
        [string]$Severity = 'Info',
        [string]$Category = 'UI',
        [hashtable]$Data,
        [switch]$Immediate
    )

    $prefix = switch ($Severity) {
        'Warn'  { '' }
        'Error' { '' }
        default { '' }
    }

    $timestamp = (Get-Date).ToString('HH:mm:ss')
    $line = "[$timestamp] $prefix $Text"

    $showToGui = $true
    try { $showToGui = (Should-LogToGui -Severity $Severity -Category $Category) } catch { $showToGui = $true }

    if ($showToGui) {
        $outputBox = Get-OutputBox

        if ($outputBox) {
            try {
                if ($outputBox.IsDisposed -or -not $outputBox.IsHandleCreated) {
                    $outputBox = $null
                }
            } catch {
                $outputBox = $null
            }
        }

        if ($outputBox) {
            try {
                $tb  = $outputBox
                $msg = $line
                $append = Get-GuiAppendAction

                if ($tb.InvokeRequired) {
                    $null = $tb.BeginInvoke($append, @($tb, $msg))
                } else {
                    $append.Invoke($tb, $msg)
                }

                if ($Immediate) {
                    [System.Windows.Forms.Application]::DoEvents()
                }
            } catch {
                Write-Host $line
            }
        } else {
            Write-Host $line
        }
    }

    try {
        Write-StructuredLog `
            -Message  $Text `
            -Severity $Severity `
            -Category $Category `
            -Context  $Data
    } catch {}

    if ($global:LogPath) {
        try {
            Add-Content -LiteralPath $global:LogPath -Value $line -Encoding UTF8
        } catch {
            Write-Host "Loggning misslyckades: $($_.Exception.Message)"
        }
    }
}

function Add-AuditEntry {
    param(
        [string]$Lsp,
        [string]$Assay,
        [string]$BatchNumber,
        [int]$TestCount,
        [string]$Status,
        [string]$ReportPath,
        [string]$AuditDir,
        [int]$TotalMs = 0,
        [string]$PhaseJson = ''
    )

    try {
        if (-not $AuditDir) {
            $netRootForAudit = ($env:IPT_NETWORK_ROOT + '').Trim()

            if ($netRootForAudit -and (Test-Path -LiteralPath $netRootForAudit)) {
                $AuditDir = Join-Path $netRootForAudit 'audit'
            }
            elseif ($PSScriptRoot) {
                $AuditDir = Join-Path $PSScriptRoot 'audit'
            }
            else {
                $AuditDir = Join-Path $env:TEMP 'audit'
            }
        }

        if (-not (Test-Path -LiteralPath $AuditDir)) {
            New-Item -ItemType Directory -Path $AuditDir -Force | Out-Null
        }

        $date = (Get-Date).ToString('yyyyMMdd')
        $safeUser = Get-SafeFileNameComponent -Value $env:USERNAME -Default 'User'
        $safeLsp  = Get-SafeFileNameComponent -Value $Lsp -Default 'NA'
        $file = Join-Path $AuditDir ("Audit_{0}_{1}_{2}.csv" -f $date, $safeUser, $safeLsp)

        $row = [pscustomobject]@{
            Timestamp  = (Get-Date).ToString('yyyy-MM-dd HH:mm:ss')
            Username   = $env:USERNAME
            LSP        = $Lsp
            Assay      = $Assay
            Batch      = $BatchNumber
            TestCount  = $TestCount
            Status     = if ($Status) { $Status } else { 'OK' }
            ReportPath = $ReportPath
            TotalMs = $TotalMs
            TotalSec = [math]::Round($TotalMs / 1000, 1)
            PhaseJson = $PhaseJson
        }
				
        $exists = Test-Path -LiteralPath $file
        if ($exists) {
            $row | Export-Csv -LiteralPath $file -NoTypeInformation -Append -Encoding UTF8
        }
        else {
            $row | Export-Csv -LiteralPath $file -NoTypeInformation -Encoding UTF8
        }
    }
    catch {
        Gui-Log -Text "Kunde inte skriva audit-fil: $($_.Exception.Message)" -Severity 'Warn' -Category 'AUDIT'
    }
}

function Write-StructuredLog {
    param(
        [string]$Message,
        [ValidateSet('Info','Warn','Error')][string]$Severity = 'Info',
        [string]$Category = 'General',
        [hashtable]$Context
    )

    if (-not $global:LogPath) { return }
		
    $jsonPath = $null
    try {
        if ($global:StructuredLogPath) {
            $jsonPath = $global:StructuredLogPath
        } else {
            $jsonPath = "$($global:LogPath).jsonl"
        }
    }
    catch {
        $jsonPath = "$($global:LogPath).jsonl"
    }

    $entry = [ordered]@{
        Timestamp = (Get-Date).ToString('o')
        Severity  = $Severity
        Category  = $Category
        Message   = $Message
    }

    if ($Context) {
        foreach ($k in $Context.Keys) {
            $entry[$k] = $Context[$k]
        }
    }

    try {
        Add-Content -LiteralPath $jsonPath -Value ($entry | ConvertTo-Json -Compress) -Encoding UTF8
    }
    catch {

    }
}
